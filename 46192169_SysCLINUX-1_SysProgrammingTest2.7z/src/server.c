/*
 * @file server.c
 * @author Shankar Karn
 * @brief Message Queue Test
 * @date 29-03-2022
 */

#include <fcntl.h>
#include <sys/types.h>
#include <mqueue.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

#define SIZE 20
#define SIZEONE 5
#define MAXSIZE 100

int main(int argc, char *argv[]){
	if(argc<2){
		fprintf(stderr,"invalid number of arguments\n");
		exit(EXIT_FAILURE);
	}
	srand(time(NULL));

	struct mq_attr attr = {0, 10,256, 0};
	int oFlags = O_CREAT|O_RDWR ;
	char *name = "/myQueue";
	printf("Creating the message Queue: \n");
	int mqDes = mq_open(name, oFlags, 0644,&attr);
	if(mqDes == -1){
		perror("mq_open");
		exit(EXIT_FAILURE);
	}
	FILE *fptr=fopen(argv[1],"r");
	if(fptr==NULL){
		perror("File error");
		exit(EXIT_FAILURE);
	}
	char line[MAXSIZE];
	
	char message[255];
	int priority;

	while(fgets(line,MAXSIZE,fptr)){
		line[strlen(line)]='\0';
		sprintf(message, "%s", line);
		fprintf(stdout,"sending message:  %s", message);
		int count=0,i=0;
		int arr[3];
		char *token=strtok(line,",");
		while(token!=NULL){
			count++;
			if(count>2 && count<=5){
				arr[i++]=atoi(token);
			}
			token=strtok(NULL,",");
		}
		priority=arr[0]*0.25+arr[1]*0.25+arr[2]*0.75;
		printf("%d\n",priority);
			
		mq_send(mqDes, message, strlen(message), priority);
	}

	int ret = mq_getattr(mqDes, &attr);

	if(ret == -1){
		perror("mq_getattr");
		exit(EXIT_FAILURE);
	}

	printf("Maximum No of Mesgs: %ld\n", attr.mq_maxmsg);
	printf("Maximum Mesg size: %ld\n", attr.mq_msgsize);
	printf("No of Mesgs in the queue: %ld\n", attr.mq_curmsgs);


	exit(EXIT_SUCCESS);
}

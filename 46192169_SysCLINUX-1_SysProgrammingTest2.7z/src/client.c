/*
 * @file client.c
 * @author Shankar Karn
 * @brief Message Queue Test
 * @date 29-03-2022
 */

#include <fcntl.h>
#include <sys/types.h>
#include <mqueue.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int main(){
	struct mq_attr attr = {0, 10,256, 0};
	int oFlags = O_RDWR ;
	char *name = "/myQueue";
	printf("Opening the message Queue: \n");
	int mqDes = mq_open(name, oFlags, 0644,&attr);

	if(mqDes == -1){
		perror("mq_open");
		exit(EXIT_FAILURE);
	}
	char message[20];
	unsigned int priority;

	int ret = mq_getattr(mqDes, &attr);

	if(ret == -1){
		perror("mq_getattr");
		exit(EXIT_FAILURE);
	}
	printf("Maximum No of Mesgs: %ld\n", attr.mq_maxmsg);
	printf("Maximum Mesg size: %ld\n", attr.mq_msgsize);
	printf("No of Mesgs in the queue: %ld\n", attr.mq_curmsgs);

	for (int cnt=0;cnt < attr.mq_curmsgs; cnt++){
		int numBytes = mq_receive(mqDes, message, attr.mq_msgsize, &priority);
		message[numBytes] = 0;
		printf("Message:  %s \t\t Priority: %u\n", message, priority);
	}

		
	printf("Deleleting the message Queue...\n");
	mqDes = mq_unlink(name);

	if(mqDes == -1){
		perror("mq_unlink");
		exit(EXIT_FAILURE);
	}

	exit(EXIT_SUCCESS);
}

